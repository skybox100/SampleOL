function globalFunc(text) {
    alert(text);
}